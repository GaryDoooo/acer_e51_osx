This folder is for kexts that are not automatically downloaded by download.sh
